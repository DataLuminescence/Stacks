from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import app

# model the class after the user table from our database
class Band:
    db = "band_together"
    def __init__( self , data ):
        self.id = data["id"]
        self.user_id = data["user_id"]
        self.band_name = data["band_name"]
        self.genre = data["genre"]
        self.homecity = data["homecity"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

#  checks if user entered appropriate data into input fields in new sighting page
    @staticmethod
    def validate_register(form_data):
        is_valid = True

        if  not form_data["band_name"] or not form_data["genre"] or not form_data["homecity"]:
            flash("All fields must be filled out to proceed", "register")
            is_valid = False
        if len(form_data["band_name"]) < 2:
            flash("Band name must be at least 2 characters long!", "register")
            is_valid = False
        if len(form_data["genre"]) < 2:
            flash("Genre must be at least 2 characters long!", "register")
            is_valid = False
        if len(form_data["homecity"]) < 2:
            flash("Home City must be at least 2 characters long!", "register")
            is_valid = False

        return is_valid

    # add band into database and returns id in register_band route "/register_band"
    @classmethod
    def create_band(cls, data):
        query = """INSERT INTO bands (user_id, band_name, genre, homecity, created_at, updated_at) 
        VALUES (%(user_id)s, %(band_name)s, %(genre)s, %(homecity)s, NOW(), NOW());"""
        results = connectToMySQL(cls.db).query_db(query, data)
        
        # returns newly created user id
        return results

    # edits band in the database and returns id 
    @classmethod
    def update_user(cls, data):
        query = "UPDATE bands SET band_name = %(band_name)s, genre = %(genre)s, homecity = %(homecity)s, updated_at = NOW() WHERE id = %(id)s;"
        return connectToMySQL("users_db").query_db(query, data)

    # delete band in the database based on id of the band
    @classmethod
    def delete_band(cls, data):
        query = "DELETE FROM bands WHERE id = %(id)s;"
        return connectToMySQL(cls.db).query_db(query, data)

    # gets query information of all bands based on user id
    @classmethod
    def get_user_and_band_by_user_id(cls,data):
        query = """SELECT * FROM users LEFT JOIN bands 
                ON bands.user_id = users.id
                WHERE users.id = %(id)s;"""
        results = connectToMySQL(cls.db).query_db(query,data)

        # returns dictionary of band data associated to an id
        return results

    # gets query information of all bands based on user id
    @classmethod
    def get_all_user_and_band(cls,data):
        query = """SELECT * FROM users LEFT JOIN bands 
                ON bands.user_id = users.id;"""
        results = connectToMySQL(cls.db).query_db(query,data)
        
        # temproary band?
        users_list = []
        # Iterate over the db results and create instances of users with cls.
        for dict in results:
            users_list.append( cls(dict) )
            print(dict)
        return users_list
        